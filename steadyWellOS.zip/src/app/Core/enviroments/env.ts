export const environment = {
  production: false,
  baseUrl: 'https://genuine-nearly-foxhound.ngrok-free.app/api/v1/',  // your local dev API
  featureFlag: true,
  version: 'dev'
};