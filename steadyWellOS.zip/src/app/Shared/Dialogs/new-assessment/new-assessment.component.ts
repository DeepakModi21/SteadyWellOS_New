import { Component } from '@angular/core';

@Component({
  selector: 'app-new-assessment',
  imports: [],
  templateUrl: './new-assessment.component.html',
  styleUrl: './new-assessment.component.css'
})
export class NewAssessmentComponent {

}
